#!/bin/sh

echo "+++++ Checking current user rights..."

if [ "$(id -u root)" = "$(id -u)" ] ; then
    :
else
    echo "ERROR: The current user id is not root (`id|awk '{print $1}'`)."
    exit 1
fi
echo

if [ "X$ACTIANZEN_ROOT" = "X" ] ; then
    ACTIANZEN_ROOT=/usr/local/actianzen
fi

LIBDIR=lib64
if [ -f $ACTIANZEN_ROOT/bin/mkded ]; then
    file -L $ACTIANZEN_ROOT/bin/mkded | grep "ELF 32-bit" >/dev/null 2>&1
    if [ $? -eq 0 ] ; then
        LIBDIR=lib
    fi
fi

PATH=$ACTIANZEN_ROOT/bin:$PATH
if [ $(uname -s) = "Darwin" ]
then
    DYLD_LIBRARY_PATH=$ACTIANZEN_ROOT/bin:$ACTIANZEN_ROOT/lib:$ACTIANZEN_ROOT/lib64:$DYLD_LIBRARY_PATH
    export DYLD_LIBRARY_PATH
    SO_EXTENSION="dylib"
    SU_ARGS="-l"
else
    LD_LIBRARY_PATH=$ACTIANZEN_ROOT/bin:$ACTIANZEN_ROOT/lib:$ACTIANZEN_ROOT/$LIBDIR:$LD_LIBRARY_PATH
    export LD_LIBRARY_PATH
    SO_EXTENSION="so"
    SU_ARGS=
fi
export ACTIANZEN_ROOT
SU="su -"
USERNAME=zen-svc
DEMODATADB="DEMODATA"
TEMPDB="TEMPDB"
RUNDAEMONFILE=/etc/init.d/actianzen

if [ $(uname -s) = "Darwin" ]
then
    RUNDAEMONFILE="$ACTIANZEN_ROOT/etc/init.d/actianzen"
    mkdir -p "$ACTIANZEN_ROOT/etc/init.d"

    MIF_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpsqlmif.${SO_EXTENSION}.* 2> /dev/null | tail -1`
    if [ "x$MIF_FILE" = "x" ]; then
        MIF_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpsqlmif.${SO_EXTENSION}.* 2> /dev/null | tail -1`
    fi
    PSCL_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpscl.${SO_EXTENSION}.* 2> /dev/null | tail -1`
    if [ "x$PSCL_FILE" = "x" ]; then
        PSCL_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpscl.${SO_EXTENSION}.* 2> /dev/null | tail -1`
    fi
    PSQL_VER=`echo $MIF_FILE | sed -e 's/^.*\.dylib\.//'`
    PS_VER=$PSQL_VER
else
    MIF_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpsqlmif.${SO_EXTENSION}.?? 2> /dev/null | tail -1`
    if [ "x$MIF_FILE" = "x" ]; then
        MIF_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpsqlmif.${SO_EXTENSION}.? 2> /dev/null | tail -1`
    fi
    PSCL_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpscl.${SO_EXTENSION}.?? 2> /dev/null | tail -1`
    if [ "x$PSCL_FILE" = "x" ]; then
        PSCL_FILE=`ls -1 $ACTIANZEN_ROOT/lib/libpscl.${SO_EXTENSION}.? 2> /dev/null | tail -1`
    fi
    PSQL_VER=`echo $MIF_FILE | sed -e 's/.*[.]\(.*\)/\1/'`
    PS_VER=$PSQL_VER
fi

# If Zen isn't running.
if ! $RUNDAEMONFILE status > /dev/null ; then
    echo "+++++ Starting the Zen daemon..."
    $RUNDAEMONFILE start
    #echo
fi


echo "+++++ Removing the $DEMODATADB database..."
DEMODATADBEXIST=`echo "$ACTIANZEN_ROOT/bin/dbmaint l" | $SU $USERNAME $SU_ARGS | grep $DEMODATADB | wc -l | tr -d " "`
if [ "X$DEMODATADBEXIST" != "X0" ] ; then
    echo "$ACTIANZEN_ROOT/bin/dbmaint d -n$DEMODATADB" | $SU $USERNAME $SU_ARGS
fi
echo


echo "+++++ Removing the $TEMPDB database..."
TEMPDBEXIST=`echo "$ACTIANZEN_ROOT/bin/dbmaint l" | $SU $USERNAME $SU_ARGS | grep $TEMPDB | wc -l | tr -d " "`
if [ "X$TEMPDBEXIST" != "X0" ] ; then
    echo "$ACTIANZEN_ROOT/bin/dbmaint d -n$TEMPDB" | $SU $USERNAME $SU_ARGS
fi
echo


echo "+++++ Stopping the Zen daemon..."
$RUNDAEMONFILE force
#echo

if [ $(uname -s) = "Darwin" ]
then
    /bin/launchctl stop com.actian.mkde

    if cd /Library/LaunchDaemons
    then
        /bin/launchctl unload com.actian.mkde.plist
        rm com.actian.mkde.plist
    fi
else
    # Use "insserv" if it's available.
    if insserv -n > /dev/null 2>&1
    then
        echo "+++++ Removing Zen daemon scripts..."
        insserv -r /etc/init.d/actianzen
        rm -f /etc/init.d/rc?.d/K??actianzen
        rm -f /etc/init.d/rc?.d/S??actianzen
        echo
    fi
fi

echo "+++++ Unregistering the PCOM libraries..."

PSREGSVR=psregsvr
if [ -f $ACTIANZEN_ROOT/bin/psregsvr64 ] ; then
    PSREGSVR=psregsvr64
fi

dso_unregister () {
    dso=$1
    if [ -f $ACTIANZEN_ROOT/$LIBDIR/$dso ]; then
        $ACTIANZEN_ROOT/bin/$PSREGSVR -u $ACTIANZEN_ROOT/$LIBDIR/$dso
    fi
}
dso_unregister libpseucjp.${SO_EXTENSION}.$PS_VER
dso_unregister libmkc3.${SO_EXTENSION}.$PSQL_VER
dso_unregister libexp010.${SO_EXTENSION}.$PSQL_VER
dso_unregister liblicmgrrb.${SO_EXTENSION}.$PSQL_VER
dso_unregister liblegacylm.${SO_EXTENSION}.$PSQL_VER
dso_unregister libmkderb.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpctlgrb.${SO_EXTENSION}.$PSQL_VER
dso_unregister libcobolschemaexecmsgrb.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpsqlcobolschemaexec.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpceurop.${SO_EXTENSION}.$PS_VER
dso_unregister libpssax.${SO_EXTENSION}.$PS_VER
dso_unregister libpsdom.${SO_EXTENSION}.$PS_VER
dso_unregister libpsutilrb.${SO_EXTENSION}.$PS_VER
dso_unregister libclientrb.${SO_EXTENSION}.$PSQL_VER
dso_unregister libupiapirb.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpvmsgrb.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpsqlcsm.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpsqlcsp.${SO_EXTENSION}.$PSQL_VER
dso_unregister libdbcsipxy.${SO_EXTENSION}.$PSQL_VER
dso_unregister libdcm100.${SO_EXTENSION}.$PSQL_VER
dso_unregister libcsi100.${SO_EXTENSION}.$PSQL_VER
dso_unregister libpscp932.${SO_EXTENSION}.$PS_VER
dso_unregister libsrderb.${SO_EXTENSION}.$PSQL_VER
echo


echo "+++++ Removing symbolic links to libraries..."

dso_unsymlink () {
    dso=$1
    if [ -h $ACTIANZEN_ROOT/lib/$dso ]; then
        rm -f $ACTIANZEN_ROOT/lib/$dso
    fi
    if [ -h $ACTIANZEN_ROOT/lib64/$dso ]; then
        rm -f $ACTIANZEN_ROOT/lib64/$dso
    fi
}
rm -f $ACTIANZEN_ROOT/bin/odbcci.${SO_EXTENSION}
dso_unsymlink libbtrvif.${SO_EXTENSION}
dso_unsymlink libdbuxlt.${SO_EXTENSION}
dso_unsymlink libiodbc.${SO_EXTENSION}
dso_unsymlink libiodbc.${SO_EXTENSION}.2
#dso_unsymlink libsdba.${SO_EXTENSION} #plohman: not used as of v11.00
#dso_unsymlink libsdba.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libsrde.${SO_EXTENSION}
dso_unsymlink libsrderb.${SO_EXTENSION}
dso_unsymlink libsrderb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlcobolschemaexec.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlcobolschemaexec.${SO_EXTENSION}
dso_unsymlink libpvisr.${SO_EXTENSION}
dso_unsymlink odbcci.${SO_EXTENSION}
dso_unsymlink odbcci.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libodbc.${SO_EXTENSION}
dso_unsymlink libodbc.${SO_EXTENSION}.1
if [ $(uname -s) = "Darwin" ]
then
    dso_unsymlink libodbccr.${SO_EXTENSION}.1
fi
dso_unsymlink libodbcci.${SO_EXTENSION}
dso_unsymlink libodbcci.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink pam_pvsw.${SO_EXTENSION}
dso_unsymlink libpscore.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpscl.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpsutilrb.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpceurop.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpseucjp.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpscp932.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpssax.${SO_EXTENSION}.$PS_VER
dso_unsymlink libpsdom.${SO_EXTENSION}.$PS_VER
dso_unsymlink libxlate.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqldti.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqldti.${SO_EXTENSION}
dso_unsymlink libclientlm.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libclientlm.${SO_EXTENSION}
dso_unsymlink libpasupt.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpasupt.${SO_EXTENSION}
dso_unsymlink libbtrieveC.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libbtrieveC.${SO_EXTENSION}
dso_unsymlink libbtrieveCpp.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libbtrieveCpp.${SO_EXTENSION}
dso_unsymlink libpsqlmif.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlmif.${SO_EXTENSION}
dso_unsymlink libpsqlnsl.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlnsl.${SO_EXTENSION}
dso_unsymlink libpctlgrb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpctlgrb.${SO_EXTENSION}
dso_unsymlink libcobolschemaexecmsgrb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libcobolschemaexecmsgrb.${SO_EXTENSION}
dso_unsymlink libclientrb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libupiapirb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpvmsgrb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libdcm100.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlmpm.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libcsi100.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlcsm.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlcsm.${SO_EXTENSION}
dso_unsymlink libpsqlcsp.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libdbcsipxy.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libenginelm.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libels.${SO_EXTENSION}
dso_unsymlink liblegacylm.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink liblicmgrrb.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libmkdemd.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpsqlmpm.${SO_EXTENSION}.$PSQL_VER
dso_unsymlink libpvisr.${SO_EXTENSION}
dso_unsymlink libpvisr.${SO_EXTENSION}.$PSQL_VER

if [ $(uname -s) != "Darwin" ]
then
    dso_unsymlink libstdc++.${SO_EXTENSION}.6
fi

echo
